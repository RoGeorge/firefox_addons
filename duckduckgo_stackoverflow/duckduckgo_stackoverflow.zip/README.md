# Stackoverflow quick search
A Firefox extension for quick searching Stackoverflow from the address bar.

Type 'ds' in the address bar followed by the search string and press ENTER.
<pre>


Usage:
  In the address bar, prefix the search string with 'ds':
  ds &lt;search string&gt;
 
Example:
  ds pyplot spectrum
written in the Firefox address bar will turn into:
  https://duckduckgo.com/?q=pyplot+spectrum+site:stackoverflow.com
</pre>
