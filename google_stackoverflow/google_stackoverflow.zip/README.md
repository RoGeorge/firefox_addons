# Stackoverflow quick search
A Firefox extension for quick searching Stackoverflow from the address bar.

Type 'gs' in the address bar followed by the search string and press ENTER.
<pre>


Usage:
  In the address bar, prefix the search string with 'gs':
  gs &lt;search string&gt;
 
Example:
  gs pyplot spectrum
written in the Firefox address bar will turn into:
  https://www.google.com/?search=pyplot+spectrum+site:stackoverflow.com
</pre>
